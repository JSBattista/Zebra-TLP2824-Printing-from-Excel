//Pertinent Links
//https://www.youtube.com/watch?v=x3WWA8eEX9Q
//https://stackoverflow.com/questions/8367902/calling-a-c-dll-in-64-bit-excel-for-use-in-vba	
//https://social.msdn.microsoft.com/Forums/en-US/f83c9511-b797-4c97-b752-cd556c6ab21e/how-do-i-get-rid-of-this-particular-excel-macro-notification-when-i-save-an-excel-file?forum=exceldev
//https://stackoverflow.com/questions/39404028/passing-strings-from-vba-to-c-dll
//http://www.informit.com/articles/article.aspx?p=2021718&seqNum=5
//https://stackoverflow.com/questions/4302364/convert-bstr-to-const-char
//https://stackoverflow.com/questions/215963/how-do-you-properly-use-widechartomultibyte
//https://msdn.microsoft.com/en-us/library/87zae4a3.aspx
//https://msdn.microsoft.com/en-us/library/ms235631.aspx
//https://msdn.microsoft.com/en-us/library/office/bb687915.aspx
//http://www.vbforums.com/showthread.php?560268-2005-Passing-strings-from-VB-net-to-C-DLL-and-back
//https://docs.microsoft.com/en-us/dotnet/visual-basic/programming-guide/program-structure/how-to-break-and-combine-statements-in-code
//https://stackoverflow.com/questions/21526863/excel-vba-selected-cells-loop
//https://stackoverflow.com/questions/971296/how-to-use-dlls-in-the-same-directory-as-an-excel-file
//
//
#include <stdio.h>
#include <windows.h>
#include <string.h>
#include <windows.h>
#include <tchar.h>
#include <stdio.h>
#include <strsafe.h>

//void __stdcall printBC(char DataBuffer[]) {
void __stdcall printBC(const char* DataBuffer) {  // A VBA String is passed as a pointer to a byte-string BSTR structure when passed ByVal, and as a pointer to a pointer when passed ByRef
	
	
	//char DataBuffer[256];  // Predictable size?
	//char *DataBuffer;
	//deb100
	// here since BSTR is in many ways WCHAR* with length prefix, it's a matter of converting const WCHAR* to const char*

	//int convertedbits = WideCharToMultiByte(CP_ACP,                // ANSI code page
	//	WC_COMPOSITECHECK,     // Check for accented characters
	//	bs,         // Source Unicode string
	//	-1,                    // -1 means string is zero-terminated
	//	DataBuffer,          // Destination char string
	//	sizeof(DataBuffer),  // Size of buffer
	//	NULL,                  // No default character
	//	NULL);                // Don't care about this flag;


//	DataBuffer[convertedbits] = '\0';  // Optional for use with arrays but if DataBuffer was declared "const char*" this would be essential


	//deb3400=========================================================
	//===========================================


	//FILE *f;
	//f = fopen("D:\\Users\\jbattista\\Desktop\\t\\debug.txt", "a");

	//fprintf(f, "in the Buffer:\n%sConverted bits = %i\n", DataBuffer, convertedbits);
	//fprintf(f, "%s,,,, %i\n", DataBuffer, sizeof(DataBuffer));
	//fprintf(f, "BSTR contents %S\n", bs);
	//fclose(f);
	//return;
	//==========================================
	//deb3400=======================================================




	HANDLE hFile;

	char printer[] = "\\\\.\\usb#vid_0a5f&pid_0016#21j113600300#{28d78fad-5a12-11d1-ae5b-0000f803a8c2}";
	//char DataBuffer[] = ".\nN\nq812\nS2\nA50, 0, 0, 1, 1, 1, N, \"Example 1 0123456789\"\nB65, 10, 0, 1, 1, 3, 50, B, \"<BARCODE,-1>\"\nP1\n.";
	//char DataBuffer[] = ".\n\
//N\n\
//q812\n\
//S2\n\
//A50,0,0,1,1,1,N,\"Example 1 0123456789\"\n\
//B65,10,0,1,1,3,50,B,\"<BARCODE,-1>\"\n\
//P1\n\
//.\n";
	//char DataBuffer[] = "Hello World!\n.";
	//DWORD dwBytesToWrite = (DWORD)strlen(DataBuffer);
	// deb100 beware this voodoo.........................................................................................
	DWORD dwBytesToWrite = (DWORD)strlen(DataBuffer);  // Expect.... possible problems? deb100
	DWORD dwBytesWritten = 0;
	BOOL bErrorFlag = FALSE;

	//printf("\n");


	hFile = CreateFile((LPCSTR)printer, //argv[1],                // name of the write
		GENERIC_WRITE,          // open for writing
		FILE_SHARE_WRITE,
		NULL,                   // default security
		OPEN_EXISTING,
		0,  // normal file
		0);                  // no attr. template

	if (hFile == INVALID_HANDLE_VALUE)
	{
		//DisplayError(LPTSTR("CreateFile"));
		//DisplayError((LPTSTR)"CreateFile")
		//_tprintf(TEXT("Terminal failure: Unable to open file \"%s\" for write.\n"), argv[1]);
		//return 0;
	}

	//_tprintf(TEXT("Writing %d bytes to %s.\n"), dwBytesToWrite, printer);

	bErrorFlag = WriteFile(
		hFile,           // open file handle
		DataBuffer,      // start of data to write
		dwBytesToWrite,  // number of bytes to write
		&dwBytesWritten, // number of bytes that were written
		NULL);            // no overlapped structure

	if (FALSE == bErrorFlag)
	{
		//DisplayError(LPTSTR("WriteFile"));
		///printf("Terminal failure: Unable to write to file.\n");
		//return 0;
	}
	else
	{
		if (dwBytesWritten != dwBytesToWrite)
		{
			// This is an error because a synchronous write that results in
			// success (WriteFile returns TRUE) should write all data as
			// requested. This would not necessarily be the case for
			// asynchronous writes.
			//printf("Error: dwBytesWritten != dwBytesToWrite\n");
		}
		else
		{
			//_tprintf(TEXT("Wrote %d bytes to %s successfully.\n"), dwBytesWritten, argv[1]);
		}
	}

	CloseHandle(hFile);
	//return 1;
}